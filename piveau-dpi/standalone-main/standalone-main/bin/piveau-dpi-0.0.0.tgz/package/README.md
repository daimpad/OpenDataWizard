# Data Provider Interface v3

Library to help developers create and manage metadata on piveau platform.

## Development

To run the app locally, you need to have [pnpm](https://pnpm.io/installation) installed.

```sh
# Install lib dependencies
pnpm install

# Install app dependencies and run it
cd app
pnpm install
pnpm dev
```

# Vue 3 + TypeScript + Vite

This template should help get you started developing with Vue 3 and TypeScript in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

Learn more about the recommended Project Setup and IDE Support in the [Vue Docs TypeScript Guide](https://vuejs.org/guide/typescript/overview.html#project-setup).
