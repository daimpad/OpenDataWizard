# @piveau/sdk-core

- Provides API client for piveau services
- Provides Zod schemas for commonly used data models
- Written in TypeScript
